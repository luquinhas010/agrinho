let plantas = [];

function setup() {
  createCanvas(800, 600);
  background(100, 200, 100); // cor do campo
}

function draw() {
  background(100, 200, 100); // campo verde
  for (let planta of plantas) {
    planta.crescer();
    planta.mostrar();
  }
}

// Plantar semente com clique
function mousePressed() {
  plantas.push(new Planta(mouseX, mouseY));
}

// Classe Planta
class Planta {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.altura = 5;
    this.maxAltura = 50;
    this.velocidade = 0.2;
    this.cor = color(34, 139, 34);
  }

  crescer() {
    if (this.altura < this.maxAltura) {
      this.altura += this.velocidade;
    }
  }

  mostrar() {
    fill(this.cor);
    noStroke();
    rect(this.x, this.y - this.altura, 5, this.altura);
    fill(0, 100, 0);
    ellipse(this.x + 2.5, this.y - this.altura, 10, 10); // folha
  }
}
